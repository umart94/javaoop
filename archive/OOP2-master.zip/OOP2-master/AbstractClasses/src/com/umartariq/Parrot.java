package com.umartariq;

public class Parrot extends Bird {
    public Parrot(String name) {
        super(name);
    }


}
