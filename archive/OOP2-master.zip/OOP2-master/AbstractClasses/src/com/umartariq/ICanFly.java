package com.umartariq;

public interface ICanFly {

    //I BELIEVEEE I CAN FLYYYY
    void fly();
}
