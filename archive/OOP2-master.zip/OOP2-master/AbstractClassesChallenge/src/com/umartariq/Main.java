package com.umartariq;

public class Main {

    public static void main(String[] args) {
	// write your code here



        //MyLinkedList linkedList = new MyLinkedList(null);
        SearchTree Searchtreeobj = new SearchTree(null);
        /*
        
        linkedList.traverse(linkedList.getRoot());
        linkedList.traverse(linkedList.getRoot());
   // String stringData = "Karachi Lahore Islamabad Murree Peshawar Quetta Multan NewYork London Paris Istanbul";
    String stringData = "5 7 3 9 8 2 1 0 4 6";
    String[] data = stringData.split(" ");//returns string array
    for(String s : data){
        //create new item with value set to the string s
        linkedList.addItem(new Node(s));
    }
    linkedList.traverse(linkedList.getRoot());
    linkedList.removeItem(new Node("3"));
        linkedList.traverse(linkedList.getRoot());


        linkedList.removeItem(new Node("5"));
        linkedList.traverse(linkedList.getRoot());


        linkedList.removeItem(new Node("0"));
        linkedList.removeItem(new Node("4"));
        linkedList.removeItem(new Node("2"));
        linkedList.traverse(linkedList.getRoot());


        linkedList.removeItem(new Node("9"));
        linkedList.traverse(linkedList.getRoot());
        linkedList.removeItem(new Node("8"));
        linkedList.traverse(linkedList.getRoot());
        linkedList.removeItem(new Node("6"));
        linkedList.traverse(linkedList.getRoot());
        linkedList.removeItem(linkedList.getRoot());
        linkedList.traverse(linkedList.getRoot());
        linkedList.removeItem(linkedList.getRoot());
        linkedList.traverse(linkedList.getRoot());

*/



        Searchtreeobj.traverse(Searchtreeobj.getRoot());
        Searchtreeobj.traverse(Searchtreeobj.getRoot());
         //String stringData = "Karachi Lahore Islamabad Murree Peshawar Quetta Multan NewYork London Paris Istanbul";
        String stringData = "5 7 3 9 8 2 1 0 4 6";
        String[] data = stringData.split(" ");//returns string array
        for(String s : data){
            //create new item with value set to the string s
            Searchtreeobj.addItem(new Node(s));
        }
        Searchtreeobj.traverse(Searchtreeobj.getRoot());
        Searchtreeobj.removeItem(new Node("3"));
        Searchtreeobj.traverse(Searchtreeobj.getRoot());


        Searchtreeobj.removeItem(new Node("5"));
        Searchtreeobj.traverse(Searchtreeobj.getRoot());


        Searchtreeobj.removeItem(new Node("0"));
        Searchtreeobj.removeItem(new Node("4"));
        Searchtreeobj.removeItem(new Node("2"));
        Searchtreeobj.traverse(Searchtreeobj.getRoot());


        Searchtreeobj.removeItem(new Node("9"));
        Searchtreeobj.traverse(Searchtreeobj.getRoot());
        Searchtreeobj.removeItem(new Node("8"));
        Searchtreeobj.traverse(Searchtreeobj.getRoot());
        Searchtreeobj.removeItem(new Node("6"));
        Searchtreeobj.traverse(Searchtreeobj.getRoot());
        Searchtreeobj.removeItem(Searchtreeobj.getRoot());
        Searchtreeobj.traverse(Searchtreeobj.getRoot());
        Searchtreeobj.removeItem(Searchtreeobj.getRoot());
        Searchtreeobj.traverse(Searchtreeobj.getRoot());
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        



    }
}
