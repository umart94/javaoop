public class Student {

    public String name;
    public int id;
    public String dept;

    public Student(String name, int id, String dept) {
        this.name = name;
        this.id = id;
        this.dept = dept;
    }


}
