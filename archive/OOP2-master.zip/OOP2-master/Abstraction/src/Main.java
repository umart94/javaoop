public class Main {

    public static void main(String[] args) {

        Shape s = new Circle("doda",5);
        Shape d = new Square("uranchooman",10);
        System.out.println(s.toString());
        System.out.println(d.toString());




    }
}
