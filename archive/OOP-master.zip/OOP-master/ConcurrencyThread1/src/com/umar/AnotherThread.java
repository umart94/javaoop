package com.umar;

import static com.umar.ThreadColor.ANSI_GREEN;

public class AnotherThread extends Thread{

    @Override
    public void run() {
        //super.run();
        System.out.println(ANSI_GREEN+"Hello From Another Thread");
    }
}
