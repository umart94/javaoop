package com.umar;

import com.umar.AnotherThread;

import static com.umar.ThreadColor.ANSI_BLUE;
import static com.umar.ThreadColor.ANSI_RED;

public class Main {

    public static void main(String[] args) {

        //A process is a unit of execution
        //process has it's own memory space (heap)
        //each instance of jvm runs as a process
        //each console app is a process
        //each javaFX app is a process


        /******** HEAP***/

        //process / application same word
        //as each process has its own heap (memory space)
        //one java application cannot access another java applications heap


        /******* THEAD *****/
        //Thread is a unit of execution inside a process
        //Each Process Can Have Multiple Threads
        //Every Process or Application in java has atleast 1 thread
        //This 1 Main Thread for UI Applications is called JavaFX application Thread

        //Every Java Process has multiple system threads
        //these handle tasks like memory management and I/O
        //We Don't Explicitly Code Those Threads
        //Our Code Runs On The Main Thread
        //Or In Other Threads That We Explicitly Create


        /*********CREATION OF THREAD (SIDE NOTE)****/
        //creating threads does not require as much resources as creating a process
        //a thread created by a process shares the process's memory and files
        //This CAN CREATE A LOT OF PROBLEMS


        /****** THREAD STACK ****/

        //In addition to a process's memory or heap
        //Each Thread Also Has What's Called a Thread Stack
        //This Thread Stack Is the memory that only the thread can access


        /***** SUMMARY ****/
        /* Each Java Application Runs as a Single Process
        Each Process Can Have Multiple Threads
        Every Process Has a Heap
        Every Thread Has a Thread Stack

         */


        /** Why Use Multiple Threads In An Application ? **/

        /*
        1. A Task That Will Take a Lot Of Time ( Database call, website data scraping)

        Code within each thread executes in a linear fashion
        so that thread wont be able to do anything else while it's waiting for data

        i.e EXECUTION OF MAIN THREAD WILL BE SUSPENDED

        Instead of working on main thread
        we can create another thread
        and execute the long running task on that thread
        this would free up the main thread

        2. 2ND REASON is that an API requires us to provide a thread
        sometimes we have to provide code that will run when a method we have called
        reaches a certain point in it's execution

        in this instance we usually dont create the tread
        we pass in the code that we want to run on the thread

         */

        /*** CONCURRENCY WHAT IS IT ? ****/

        /*
        CONCURRENCY Refers to An Application Doing more than 1 thing at a time
        example ( application wants to download data and draw a shape on the screen)

        If it's a concurrent application, it can download a bit of data
        then switch to drawing a part of shape
        then switch back to downloading more data
        switch back to drawing more of shape

        concurrency means that one task doesnt have to complete before
        another can start

        Java provides Thread Related classes so we can create concurrent applications

         */


        System.out.println(ANSI_RED+"HELLO FROM MAIN THREAD");

        Thread anotherThread = new AnotherThread();
        // will run the run method from thread
//use the run / start method only once
        anotherThread.start();

        new Thread(){
            @Override
            public void run() {
                System.out.println(ANSI_BLUE+"Hello from anonymous class");
            }
        }.start();

        System.out.println(ANSI_RED+"HELLO FROM AFTER MAIN THREAD ");


        //anotherThread.start();//will throw illegalthreadstateexception







    }
}
