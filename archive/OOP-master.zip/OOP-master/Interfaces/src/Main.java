public class Main {

    public static void main(String[] args) {
        /*Interfaces
        methods that (class that implements an interface) must implement

        Interface only has methods
        actual method definitions are inside the classes

         */

        ITelephone umarPhone;
        umarPhone = new DeskPhone(123456);
    }
}
