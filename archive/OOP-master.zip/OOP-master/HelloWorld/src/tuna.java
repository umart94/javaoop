public class tuna {

    public void simpleMessage(){

        System.out.println("This is another class");
    }
}
