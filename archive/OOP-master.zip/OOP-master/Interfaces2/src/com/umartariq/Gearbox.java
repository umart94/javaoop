package com.umartariq;

public class Gearbox {
    private boolean clutchIsIn;

    public void operateClutch(String inOrOut) {

        this.clutchIsIn = inOrOut.equalsIgnoreCase("in");
        //parameter can also be a boolean
        // this would change the method definition declaration
        //in implementing interface .. we sign contract
        //that the method will not change



    }
}
